from utils.DBRead import DBRead
from utils.ExcelRead import ExcelRead
class DataRead:
    def read(self,mode="database",param="加法",filename="",sheetname="",user="root",passwdrd="root",database="Calc"):
        if mode == "excel":
            er = ExcelRead()
            return er.readData(filename=filename,sheetname=sheetname)
        elif mode == "database":
            db = DBRead()
            return db.find(param=param,user=user,password=passwdrd,database=database)
        else:
            print("输入非法！！！")

