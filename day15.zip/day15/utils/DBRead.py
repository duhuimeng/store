import pymysql
class DBRead:
    def find(self,param="testAdd",user="root",password="root",database="Calc"):
        con = pymysql.connect(host="localhost", user=user, password=password, database=database)
        cursor = con.cursor()
        if param == "加法":
            sql = "select * from testadd"
            cursor.execute(sql)
            con.commit()
            return cursor.fetchall()
        elif param == "减法":
            sql = "select * from testsub"
            cursor.execute(sql)
            con.commit()
            return cursor.fetchall()
        elif param == "乘法":
            sql = "select * from testmulti"
            cursor.execute(sql)
            con.commit()
            return cursor.fetchall()
        elif param == "除法":
            sql = "select * from testdevision"
            cursor.execute(sql)
            con.commit()
            return cursor.fetchall()
        cursor.close()
        con.close()