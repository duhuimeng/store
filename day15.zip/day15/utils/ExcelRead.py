import xlrd

class ExcelRead:

    def readData(self,filename="",sheetname=1):
        wb = xlrd.open_workbook(filename=filename,encoding_override="utf-8")
        li = []
        if str(sheetname).isdigit():
            st = wb.sheet_by_index(sheetname)
            rows = st.nrows
            for i in range(rows):
                li.append(st.row_values(i))
            return li
        else:
            st = wb.sheet_by_name(sheetname)
            rows = st.nrows
            for i in range(rows):
                li.append(st.row_values(i))
            return li