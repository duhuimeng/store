from utils.DataRead import DataRead
import unittest
from ddt import ddt
from ddt import data
from ddt import unpack
from entity.Calc import Calc

data1 = DataRead().read(mode = "excel",filename="D:\PycharmProjects\day15\datasource\测试数据.xls",sheetname=0)
data2 = DataRead().read(mode = "excel",filename="D:\PycharmProjects\day15\datasource\测试数据.xls",sheetname=1)
data3 = DataRead().read(mode = "excel",filename="D:\PycharmProjects\day15\datasource\测试数据.xls",sheetname=2)
data4 = DataRead().read(mode = "excel",filename="D:\PycharmProjects\day15\datasource\测试数据.xls",sheetname=3)
#data1 = DataRead().read(mode = "database",param="加法")
#data2 = DataRead().read(mode = "database",param="减法")
#data3 = DataRead().read(mode = "database",param="乘法")
#data4 = DataRead().read(mode = "database",param="除法")
@ddt
class TestCalc(unittest.TestCase):

    @data(*data1)
    @unpack
    def testAdd(self,a,b,c):
        calc = Calc()
        sum = calc.add(a,b)
        self.assertEqual(sum,c)

    @data(*data2)
    @unpack
    def testSub(self,a,b,c):
        calc = Calc()
        sum = calc.sub(a,b)
        self.assertEqual(sum,c)

    @data(*data3)
    @unpack
    def testMulti(self,a,b,c):
        calc = Calc()
        sum = calc.multi(a,b)
        self.assertEqual(sum,c)

    @data(*data4)
    @unpack
    def testDevision(self,a,b,c):
        calc = Calc()
        sum = calc.devision(a,b)
        self.assertEqual(sum,c)

