import unittest
from HTMLTestRunner import HTMLTestRunner
# 创建测试集
suite = unittest.TestSuite()

# 使用测试加载器集中加载
loader =unittest.defaultTestLoader
tests = loader.discover("D:\\PycharmProjects\\day15\\tastcase",pattern="Test*.py")

suite.addTest(tests)

# 使用html运行器生成报告
#f =  open("计算器测试报告Excel.html","w+",encoding="utf-8")
f =  open("计算器测试报告MySQL.html","w+",encoding="utf-8")
runner = HTMLTestRunner.HTMLTestRunner(
    stream=f,
    title="报告",
    verbosity=1,
    description="这是一个非常详细测试报告"
)
runner.run(suite)

# 加上email邮件发送