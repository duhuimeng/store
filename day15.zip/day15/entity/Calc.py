
class Calc:
    def add(self,a,b):
        return a + b

    def sub(self,a,b):
        return a - b

    def multi(self,a,b):
        return a * b

    def devision(self,a,b):
        return a / b
