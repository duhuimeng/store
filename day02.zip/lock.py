import time

num=0
name=("120")
mima=("119")
while True:
    username = input("请输入用户名：")
    password = input("请输入密码：")
    if username != name or password != mima:
        num=num+1
        print("用户名或密码输入错误！")
        if num>=3:
            for i in range(30, 0, -1):
                print("您已输入错误3次，系统锁定", i, "秒！")
                time.sleep(1)
            num=0
    else:
        print("登录成功")
        break