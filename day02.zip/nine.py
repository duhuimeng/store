i=1
while i<=9:
    j=1
    while j<=10-i:
        print(i,"X",j,"=",(j*i)," ","\t",end="")
        j=j+1
    print()
    i=i+1
    