a=56
b=78
c=a+b
b=c-b
a=c-a
print(a,b)