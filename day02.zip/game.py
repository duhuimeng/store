import random
import time



gold=200
print("欢迎来到猜数字游戏，您将用金币进行猜数字游戏，每20金币一次，猜中获得120金币，初始拥有200金币。")
print("开始游戏吧！")
while True:
    if gold>=0 and gold<20:
        break
    num = random.randint(1, 100)
    print(num)
    i=0
    k=0
    while True:
        if k>=3:
           print("您已经猜错3次，系统锁定5秒！")
           j=1
           while j<=5:
              print(".",end="")
              time.sleep(1)
              j=j+1
              k=0
        i=i+1
        k=k+1
        gold=gold-20
        n=input("请输入一个数字：")
        n=int(n)
        if n>num:
           print("太大！")
           if gold>=0 and gold<20:
               print("您的金币不足，请充值-_-||")
               break
        elif n<num:
           print("太小！")
           if gold>=0 and gold<20:
               print("您的金币不足，请充值-_-||")
               break
        else:
           gold=gold+120
           print()
           print("恭喜您，猜中了！")
           print("您一共猜了：", i, "次！")
           print("您现在拥有",gold,"金币。")
           print()
           break