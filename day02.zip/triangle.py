i=input("请输入边长：")
j=input("请输入边长：")
k=input("请输入边长：")
i=int(i)
j=int(j)
k=int(k)
if i>0 and j>0 and k>0 and i+j>=k and i+k>=j and j+k>=i:
    if i==j==k:
        print("这是等边三角形！")
    elif i==j or i==k or j==k:
        print("这是等腰三角形！")
    elif i+j==k or i+k==j or j+k==i:
        print("这是直角三角形！")
    else:
        print("这是普通三角形！")
else:
    print("这不是三角形！")