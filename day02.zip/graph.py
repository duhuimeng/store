i=1
while i<=7:
    j=1
    while j<=7-i:
        print(" ",end="")
        j=j+1
    k=1
    while k<=i:
        print("* ",end="")
        k=k+1
    print()
    i=i+1